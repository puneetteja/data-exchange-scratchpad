"""
app_a.py — Databricks App: Send a POST request with metadata and a PDF file.

Usage (in a Databricks notebook or job):
    %pip install requests
    # Then run this script or import it.

Set the target URL to wherever app_b is hosted, e.g.:
    TARGET_URL = "https://<your-databricks-workspace>.azuredatabricks.net/driver-proxy/o/.../8080/upload"
or a local cluster address during development.
"""

import requests
import os

# ── Configuration ────────────────────────────────────────────────────────────
TARGET_URL = "http://localhost:8080/upload"   # <-- change to app_b's URL
PDF_PATH   = "/tmp/sample.pdf"                # path to the PDF you want to send
# ─────────────────────────────────────────────────────────────────────────────


def create_sample_pdf(path: str) -> None:
    """Create a minimal one-page PDF for testing (no extra libraries needed)."""
    content = b"""%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]
  /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj
4 0 obj << /Length 44 >>
stream
BT /F1 24 Tf 100 700 Td (Hello from app_a!) Tj ET
endstream
endobj
5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000266 00000 n 
0000000360 00000 n 
trailer << /Size 6 /Root 1 0 R >>
startxref
441
%%EOF"""
    with open(path, "wb") as f:
        f.write(content)
    print(f"[app_a] Sample PDF created at: {path}")


def send_request(url: str, pdf_path: str) -> None:
    """POST metadata fields + a PDF file to app_b."""

    if not os.path.exists(pdf_path):
        print(f"[app_a] PDF not found at {pdf_path}, creating a sample one…")
        create_sample_pdf(pdf_path)

    metadata = {
        "sender":      "app_a",
        "description": "Monthly report",
        "version":     "1.0",
    }

    with open(pdf_path, "rb") as pdf_file:
        files   = {"document": (os.path.basename(pdf_path), pdf_file, "application/pdf")}
        payload = metadata          # sent as multipart form fields alongside the file

        print(f"[app_a] Sending POST to {url} …")
        try:
            response = requests.post(url, data=payload, files=files, timeout=30)
            print(f"[app_a] Response status : {response.status_code}")
            print(f"[app_a] Response body   : {response.text}")
        except requests.exceptions.ConnectionError as exc:
            print(f"[app_a] Connection error — is app_b running? ({exc})")


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    send_request(TARGET_URL, PDF_PATH)
