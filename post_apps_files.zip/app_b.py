"""
app_b.py — Databricks App: Receive a POST request and save the uploaded PDF.

Usage (in a Databricks notebook or job):
    %pip install flask
    # Then run this script.  On Databricks the built-in proxy exposes port 8080
    # as a public HTTPS endpoint automatically.

The server listens on 0.0.0.0:8080 and exposes two endpoints:
    POST /upload  — accepts multipart/form-data with a 'document' file field
    GET  /health  — simple liveness check
"""

import os
from datetime import datetime
from flask import Flask, request, jsonify

# ── Configuration ─────────────────────────────────────────────────────────────
UPLOAD_DIR = "/tmp/received_documents"   # where PDFs are saved
HOST       = "0.0.0.0"
PORT       = 8080
# ─────────────────────────────────────────────────────────────────────────────

os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)


@app.route("/health", methods=["GET"])
def health():
    """Liveness probe — confirms the server is running."""
    return jsonify({"status": "ok", "service": "app_b"}), 200


@app.route("/upload", methods=["POST"])
def upload():
    """
    Accept a multipart POST that contains:
      - optional text fields (metadata)
      - a file field named 'document'

    Saves the PDF to UPLOAD_DIR and returns a JSON summary.
    """

    # ── 1. Validate that a file was included ──────────────────────────────────
    if "document" not in request.files:
        return jsonify({"error": "No 'document' field found in the request."}), 400

    file = request.files["document"]

    if file.filename == "":
        return jsonify({"error": "Filename is empty."}), 400

    # ── 2. Build a unique filename so reruns don't overwrite each other ───────
    timestamp    = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    safe_name    = os.path.basename(file.filename)          # strip any path traversal
    save_name    = f"{timestamp}_{safe_name}"
    save_path    = os.path.join(UPLOAD_DIR, save_name)

    # ── 3. Save the file ──────────────────────────────────────────────────────
    file.save(save_path)
    file_size = os.path.getsize(save_path)
    print(f"[app_b] Saved '{save_name}' ({file_size} bytes) to {UPLOAD_DIR}")

    # ── 4. Read any extra metadata fields ────────────────────────────────────
    metadata = {k: v for k, v in request.form.items()}

    return jsonify({
        "status":    "received",
        "saved_as":  save_path,
        "size_bytes": file_size,
        "metadata":  metadata,
    }), 200


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"[app_b] Starting server on {HOST}:{PORT}")
    print(f"[app_b] Uploads will be saved to: {UPLOAD_DIR}")
    # debug=False for production; use True only while developing locally
    app.run(host=HOST, port=PORT, debug=False)
