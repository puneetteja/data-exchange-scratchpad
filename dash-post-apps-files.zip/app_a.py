"""
app_a.py — Databricks Dash App: Send a POST request with metadata and a PDF file.

Usage (in a Databricks notebook):
    %pip install dash requests
    exec(open("app_a.py").read())

The Dash UI runs on port 8050. Set TARGET_URL to app_b's /upload endpoint.
"""

import base64
import os
import requests
import dash
from dash import dcc, html, Input, Output, State

# ── Configuration ─────────────────────────────────────────────────────────────
TARGET_URL = "http://localhost:8080/upload"   # <-- change to app_b's URL
HOST       = "0.0.0.0"
PORT       = 8050
# ─────────────────────────────────────────────────────────────────────────────

SAMPLE_PDF = b"""%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]
  /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj
4 0 obj << /Length 44 >>
stream
BT /F1 24 Tf 100 700 Td (Hello from app_a!) Tj ET
endstream
endobj
5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000266 00000 n 
0000000360 00000 n 
trailer << /Size 6 /Root 1 0 R >>
startxref
441
%%EOF"""

# ── Layout ────────────────────────────────────────────────────────────────────
app = dash.Dash(__name__)

app.layout = html.Div(
    style={"fontFamily": "Arial, sans-serif", "maxWidth": "640px",
           "margin": "40px auto", "padding": "0 20px"},
    children=[
        html.H2("app_a — PDF Sender", style={"marginBottom": "24px"}),

        html.Label("Target URL (app_b /upload endpoint)"),
        dcc.Input(id="url-input", value=TARGET_URL, type="text",
                  style={"width": "100%", "marginBottom": "16px", "padding": "6px"}),

        html.Label("Sender"),
        dcc.Input(id="sender-input", value="app_a", type="text",
                  style={"width": "100%", "marginBottom": "16px", "padding": "6px"}),

        html.Label("Description"),
        dcc.Input(id="desc-input", value="Monthly report", type="text",
                  style={"width": "100%", "marginBottom": "16px", "padding": "6px"}),

        html.Label("Version"),
        dcc.Input(id="ver-input", value="1.0", type="text",
                  style={"width": "100%", "marginBottom": "16px", "padding": "6px"}),

        html.Label("PDF File (optional — uses built-in sample if omitted)"),
        dcc.Upload(
            id="upload-pdf",
            children=html.Div(["Drag & drop or ", html.A("select a PDF")]),
            style={
                "width": "100%", "borderWidth": "1px", "borderStyle": "dashed",
                "borderRadius": "4px", "textAlign": "center", "padding": "20px",
                "marginBottom": "8px", "cursor": "pointer",
            },
            accept=".pdf",
        ),
        html.Div(id="upload-label",
                 style={"marginBottom": "20px", "color": "#555", "fontSize": "13px"}),

        html.Button(
            "Send POST Request", id="send-btn", n_clicks=0,
            style={"padding": "10px 24px", "fontSize": "15px", "cursor": "pointer",
                   "backgroundColor": "#1a73e8", "color": "white",
                   "border": "none", "borderRadius": "4px"},
        ),

        html.Hr(),
        html.Div(id="result-output",
                 style={"whiteSpace": "pre-wrap", "fontFamily": "monospace",
                        "fontSize": "13px"}),
    ],
)


# ── Callbacks ─────────────────────────────────────────────────────────────────

@app.callback(
    Output("upload-label", "children"),
    Input("upload-pdf", "filename"),
)
def show_filename(filename):
    return (f"Selected: {filename}" if filename
            else "No file selected — sample PDF will be used.")


@app.callback(
    Output("result-output", "children"),
    Input("send-btn", "n_clicks"),
    State("url-input",    "value"),
    State("sender-input", "value"),
    State("desc-input",   "value"),
    State("ver-input",    "value"),
    State("upload-pdf",   "contents"),
    State("upload-pdf",   "filename"),
    prevent_initial_call=True,
)
def send_request(n_clicks, url, sender, description, version,
                 contents, filename):
    metadata = {
        "sender":      sender      or "",
        "description": description or "",
        "version":     version     or "",
    }

    # Decode uploaded file, or fall back to the built-in sample
    if contents:
        _header, encoded = contents.split(",", 1)
        pdf_bytes = base64.b64decode(encoded)
        pdf_name  = filename or "upload.pdf"
    else:
        pdf_bytes = SAMPLE_PDF
        pdf_name  = "sample.pdf"

    try:
        files    = {"document": (pdf_name, pdf_bytes, "application/pdf")}
        response = requests.post(url, data=metadata, files=files, timeout=30)
        return (f"Status : {response.status_code}\n"
                f"Body   : {response.text}")
    except requests.exceptions.ConnectionError as exc:
        return f"Connection error — is app_b running?\n{exc}"
    except Exception as exc:
        return f"Unexpected error:\n{exc}"


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=False)
