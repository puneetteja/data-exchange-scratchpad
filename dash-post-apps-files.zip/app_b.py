"""
app_b.py — Databricks Dash App: Receive a POST request and save the uploaded PDF.

Usage (in a Databricks notebook):
    %pip install dash flask
    exec(open("app_b.py").read())

Exposes two endpoints:
    POST /upload  — multipart/form-data with a 'document' file field
    GET  /health  — liveness check

The Dash UI (port 8080) shows a live log of every received file.
Refresh the page (or click Refresh Log) to see new entries.
"""

import os
import json
from datetime import datetime, timezone

import flask
from dash import Dash, html, dcc, Input, Output

# ── Configuration ─────────────────────────────────────────────────────────────
UPLOAD_DIR = "/tmp/received_documents"
HOST       = "0.0.0.0"
PORT       = 8080
# ─────────────────────────────────────────────────────────────────────────────

os.makedirs(UPLOAD_DIR, exist_ok=True)

# Dash wraps a Flask server — grab it so we can add custom routes
server = flask.Flask(__name__)
app    = Dash(__name__, server=server)

# In-memory log (list of dicts); persists as long as the process runs
received_log: list[dict] = []


# ── Custom Flask routes (the actual POST endpoint) ────────────────────────────

@server.route("/health", methods=["GET"])
def health():
    return flask.jsonify({"status": "ok", "service": "app_b"}), 200


@server.route("/upload", methods=["POST"])
def upload():
    if "document" not in flask.request.files:
        return flask.jsonify({"error": "No 'document' field in request."}), 400

    file = flask.request.files["document"]
    if file.filename == "":
        return flask.jsonify({"error": "Filename is empty."}), 400

    # Build a timestamped filename to avoid collisions
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    safe_name = os.path.basename(file.filename)
    save_name = f"{timestamp}_{safe_name}"
    save_path = os.path.join(UPLOAD_DIR, save_name)

    file.save(save_path)
    file_size = os.path.getsize(save_path)

    metadata = dict(flask.request.form)
    entry = {
        "timestamp": timestamp,
        "filename":  save_name,
        "size_bytes": file_size,
        "saved_to":  save_path,
        "metadata":  metadata,
    }
    received_log.append(entry)

    print(f"[app_b] Saved '{save_name}' ({file_size} bytes)")
    return flask.jsonify({"status": "received", **entry}), 200


# ── Dash layout (live log viewer) ─────────────────────────────────────────────

app.layout = html.Div(
    style={"fontFamily": "Arial, sans-serif", "maxWidth": "760px",
           "margin": "40px auto", "padding": "0 20px"},
    children=[
        html.H2("app_b — PDF Receiver", style={"marginBottom": "4px"}),
        html.P(f"Listening for POST requests at  {HOST}:{PORT}/upload",
               style={"color": "#555", "marginBottom": "20px", "fontSize": "13px"}),

        html.Button("↻ Refresh Log", id="refresh-btn", n_clicks=0,
                    style={"padding": "8px 18px", "cursor": "pointer",
                           "marginBottom": "16px", "borderRadius": "4px",
                           "border": "1px solid #ccc", "fontSize": "13px"}),

        html.Div(id="log-container"),

        # Interval for auto-refresh every 5 s
        dcc.Interval(id="interval", interval=5_000, n_intervals=0),
    ],
)


@app.callback(
    Output("log-container", "children"),
    Input("refresh-btn",   "n_clicks"),
    Input("interval",      "n_intervals"),
)
def refresh_log(_clicks, _intervals):
    if not received_log:
        return html.P("No files received yet.",
                      style={"color": "#888", "fontStyle": "italic"})

    rows = []
    for entry in reversed(received_log):   # newest first
        meta_str = json.dumps(entry["metadata"], ensure_ascii=False)
        rows.append(
            html.Div(
                style={"border": "1px solid #ddd", "borderRadius": "6px",
                       "padding": "12px 16px", "marginBottom": "10px",
                       "backgroundColor": "#f9f9f9"},
                children=[
                    html.Div(
                        html.Strong(entry["filename"]),
                        style={"marginBottom": "4px"},
                    ),
                    html.Div(
                        f"Received: {entry['timestamp']}  |  "
                        f"Size: {entry['size_bytes']} bytes  |  "
                        f"Saved to: {entry['saved_to']}",
                        style={"fontSize": "12px", "color": "#555",
                               "marginBottom": "4px"},
                    ),
                    html.Div(
                        f"Metadata: {meta_str}",
                        style={"fontSize": "12px", "color": "#444",
                               "fontFamily": "monospace"},
                    ),
                ],
            )
        )
    return rows


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"[app_b] Starting on {HOST}:{PORT}")
    print(f"[app_b] Saving uploads to: {UPLOAD_DIR}")
    app.run(host=HOST, port=PORT, debug=False)
