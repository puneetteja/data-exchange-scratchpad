"""
app_a.py — Databricks Dash App: Send a POST request + PDF using an OAuth M2M token.

Usage (in a Databricks notebook):
    %pip install dash requests
    exec(open("app_a.py").read())

OAuth M2M setup
---------------
1. Create a service principal in your Databricks account console.
2. Generate a client_id + client_secret for it.
3. Store those credentials in a Databricks secret scope:

    databricks secrets create-scope my-scope
    databricks secrets put-secret my-scope sp-client-id     --string-value <CLIENT_ID>
    databricks secrets put-secret my-scope sp-client-secret --string-value <CLIENT_SECRET>

4. Set DATABRICKS_HOST, SECRET_SCOPE, and the two SECRET_KEY_* values below.

At runtime app_a calls the Databricks OAuth token endpoint to obtain a
short-lived Bearer token, then attaches it to every POST request to app_b.
The token is cached for its lifetime (typically 1 hour) and refreshed
automatically when it expires.
"""

import base64
import os
import time
import requests
import dash
from dash import dcc, html, Input, Output, State

# ── Configuration ─────────────────────────────────────────────────────────────
TARGET_URL          = "http://localhost:8080/upload"  # <-- app_b's /upload URL
DATABRICKS_HOST     = "https://<your-workspace>.azuredatabricks.net"  # <-- set this
SECRET_SCOPE        = "my-scope"          # <-- secret scope name
SECRET_KEY_ID       = "sp-client-id"      # <-- key holding the client_id
SECRET_KEY_SECRET   = "sp-client-secret"  # <-- key holding the client_secret
HOST                = "0.0.0.0"
PORT                = 8050
# ─────────────────────────────────────────────────────────────────────────────

SAMPLE_PDF = b"""%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]
  /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj
4 0 obj << /Length 44 >>
stream
BT /F1 24 Tf 100 700 Td (Hello from app_a!) Tj ET
endstream
endobj
5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000266 00000 n 
0000000360 00000 n 
trailer << /Size 6 /Root 1 0 R >>
startxref
441
%%EOF"""


# ── OAuth M2M token cache ─────────────────────────────────────────────────────

class _TokenCache:
    """Fetches and caches an OAuth M2M token; refreshes when it expires."""

    def __init__(self):
        self._token:   str   = ""
        self._expires: float = 0.0   # unix timestamp

    def _load_credentials(self):
        """Read client_id and client_secret from the Databricks secret scope."""
        try:
            client_id     = dbutils.secrets.get(scope=SECRET_SCOPE, key=SECRET_KEY_ID)      # noqa: F821
            client_secret = dbutils.secrets.get(scope=SECRET_SCOPE, key=SECRET_KEY_SECRET)  # noqa: F821
            return client_id, client_secret
        except Exception as exc:
            raise RuntimeError(
                f"Could not load credentials from secret scope '{SECRET_SCOPE}': {exc}"
            ) from exc

    def _fetch(self) -> tuple[str, float]:
        """Exchange client credentials for an access token via the M2M flow."""
        client_id, client_secret = self._load_credentials()

        token_url = f"{DATABRICKS_HOST.rstrip('/')}/oidc/v1/token"
        resp = requests.post(
            token_url,
            data={
                "grant_type":    "client_credentials",
                "scope":         "all-apis",
            },
            auth=(client_id, client_secret),
            timeout=15,
        )
        resp.raise_for_status()
        body       = resp.json()
        token      = body["access_token"]
        expires_in = int(body.get("expires_in", 3600))
        # Subtract 60 s buffer so we refresh before actual expiry
        expires_at = time.time() + expires_in - 60
        return token, expires_at

    def get(self) -> str:
        """Return a valid access token, refreshing if necessary."""
        if not self._token or time.time() >= self._expires:
            self._token, self._expires = self._fetch()
        return self._token


_token_cache = _TokenCache()


def _boot_token_status() -> tuple[str, str]:
    """Try to fetch a token at startup; return (status_message, color)."""
    try:
        _token_cache.get()
        return "✓ OAuth M2M credentials loaded from secret scope.", "#2a7a2a"
    except Exception as exc:
        return f"⚠ Could not load credentials: {exc}", "#b36b00"


_boot_msg, _boot_color = _boot_token_status()

# ── Dash layout ───────────────────────────────────────────────────────────────
app = dash.Dash(__name__)

S = {
    "input": {"width": "100%", "marginBottom": "16px", "padding": "6px"},
    "label": {"display": "block", "marginBottom": "4px",
               "fontWeight": "bold", "fontSize": "13px"},
    "hint":  {"fontSize": "12px", "marginBottom": "16px"},
    "btn":   {"padding": "10px 24px", "fontSize": "15px", "cursor": "pointer",
               "backgroundColor": "#1a73e8", "color": "white",
               "border": "none", "borderRadius": "4px"},
}

app.layout = html.Div(
    style={"fontFamily": "Arial, sans-serif", "maxWidth": "640px",
           "margin": "40px auto", "padding": "0 20px"},
    children=[
        html.H2("app_a — PDF Sender (OAuth M2M)"),

        # Auth status banner
        html.Div(_boot_msg,
                 style={"color": _boot_color, "fontSize": "13px",
                        "marginBottom": "20px", "padding": "8px 12px",
                        "border": f"1px solid {_boot_color}",
                        "borderRadius": "4px", "backgroundColor": "#f9f9f9"}),

        # Target URL
        html.Label("Target URL (app_b /upload endpoint)", style=S["label"]),
        dcc.Input(id="url-input", value=TARGET_URL, type="text", style=S["input"]),

        # Metadata
        html.Label("Sender",      style=S["label"]),
        dcc.Input(id="sender-input", value="app_a", type="text", style=S["input"]),

        html.Label("Description", style=S["label"]),
        dcc.Input(id="desc-input", value="Monthly report", type="text",
                  style=S["input"]),

        html.Label("Version",     style=S["label"]),
        dcc.Input(id="ver-input",  value="1.0", type="text", style=S["input"]),

        # PDF upload
        html.Label("PDF File (optional — uses built-in sample if omitted)",
                   style=S["label"]),
        dcc.Upload(
            id="upload-pdf",
            children=html.Div(["Drag & drop or ", html.A("select a PDF")]),
            accept=".pdf",
            style={"width": "100%", "border": "1px dashed #aaa",
                   "borderRadius": "4px", "textAlign": "center",
                   "padding": "20px", "marginBottom": "6px", "cursor": "pointer"},
        ),
        html.Div(id="upload-label", style={**S["hint"], "color": "#555"}),

        html.Button("Send POST Request", id="send-btn", n_clicks=0, style=S["btn"]),
        html.Hr(),
        html.Div(id="result-output",
                 style={"whiteSpace": "pre-wrap", "fontFamily": "monospace",
                        "fontSize": "13px"}),
    ],
)


# ── Callbacks ─────────────────────────────────────────────────────────────────

@app.callback(
    Output("upload-label", "children"),
    Input("upload-pdf", "filename"),
)
def show_filename(filename):
    return (f"Selected: {filename}" if filename
            else "No file selected — sample PDF will be used.")


@app.callback(
    Output("result-output", "children"),
    Input("send-btn", "n_clicks"),
    State("url-input",    "value"),
    State("sender-input", "value"),
    State("desc-input",   "value"),
    State("ver-input",    "value"),
    State("upload-pdf",   "contents"),
    State("upload-pdf",   "filename"),
    prevent_initial_call=True,
)
def send_request(_, url, sender, description, version, contents, filename):
    # Obtain a valid (possibly cached) OAuth token
    try:
        token = _token_cache.get()
    except Exception as exc:
        return f"✗ Could not obtain OAuth token:\n{exc}"

    headers = {"Authorization": f"Bearer {token}"}

    # Resolve PDF bytes
    if contents:
        _header, encoded = contents.split(",", 1)
        pdf_bytes = base64.b64decode(encoded)
        pdf_name  = filename or "upload.pdf"
    else:
        pdf_bytes = SAMPLE_PDF
        pdf_name  = "sample.pdf"

    metadata = {
        "sender":      sender      or "",
        "description": description or "",
        "version":     version     or "",
    }

    try:
        files    = {"document": (pdf_name, pdf_bytes, "application/pdf")}
        response = requests.post(url, data=metadata, files=files,
                                 headers=headers, timeout=30)
        icon = "✓" if response.status_code == 200 else "✗"
        return (f"{icon} Status : {response.status_code}\n"
                f"  Body   : {response.text}")
    except requests.exceptions.ConnectionError as exc:
        return f"✗ Connection error — is app_b running?\n{exc}"
    except Exception as exc:
        return f"✗ Unexpected error:\n{exc}"


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=False)
