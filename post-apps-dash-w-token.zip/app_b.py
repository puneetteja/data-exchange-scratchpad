"""
app_b.py — Databricks Dash App: Receive authenticated POST requests and save PDFs.

Usage (in a Databricks notebook):
    %pip install dash flask requests
    exec(open("app_b.py").read())

OAuth M2M validation
--------------------
app_b does NOT share a secret with app_a. Instead it validates the incoming
Bearer token by calling the Databricks token introspection endpoint:

    POST <DATABRICKS_HOST>/oidc/v1/introspect

This is the correct pattern for OAuth M2M (service principal) tokens — the
receiver delegates trust entirely to Databricks rather than comparing secrets.

Optionally set REQUIRED_SP_CLIENT_ID to restrict access to a specific
service principal (recommended for production). Leave blank to accept any
valid Databricks M2M token.
"""

import os
import json
import functools
from datetime import datetime, timezone

import flask
import requests as http
from dash import Dash, html, dcc, Input, Output

# ── Configuration ─────────────────────────────────────────────────────────────
DATABRICKS_HOST       = "https://<your-workspace>.azuredatabricks.net"  # <-- set this
REQUIRED_SP_CLIENT_ID = ""               # <-- optional: pin to one service principal
UPLOAD_DIR            = "/tmp/received_documents"
HOST                  = "0.0.0.0"
PORT                  = 8080
# ─────────────────────────────────────────────────────────────────────────────

os.makedirs(UPLOAD_DIR, exist_ok=True)

INTROSPECT_URL = f"{DATABRICKS_HOST.rstrip('/')}/oidc/v1/introspect"

# ── Flask + Dash setup ────────────────────────────────────────────────────────
server = flask.Flask(__name__)
app    = Dash(__name__, server=server)

received_log: list[dict] = []


# ── Auth helper ───────────────────────────────────────────────────────────────

def _introspect(token: str) -> dict:
    """
    Call the Databricks introspection endpoint.
    Returns the introspection response dict.
    Raises RuntimeError if the HTTP call itself fails.
    """
    resp = http.post(
        INTROSPECT_URL,
        data={"token": token},
        # The introspect endpoint accepts the token being checked as the
        # credential (self-introspection), which is supported by Databricks.
        headers={"Authorization": f"Bearer {token}"},
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()


def require_m2m_token(f):
    """
    Decorator: validates an OAuth M2M Bearer token on every incoming request.

    Steps:
      1. Extract the Bearer token from the Authorization header.
      2. Call the Databricks introspection endpoint to verify it is active.
      3. Confirm the token was issued to a service principal (sub starts with
         'ServicePrincipal/' or client_id is present), not a human user.
      4. Optionally enforce that the client_id matches REQUIRED_SP_CLIENT_ID.
    """
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        auth_header = flask.request.headers.get("Authorization", "")

        if not auth_header.startswith("Bearer "):
            return flask.jsonify(
                {"error": "Missing or malformed Authorization header. "
                          "Expected: Bearer <token>"}), 401

        token = auth_header[len("Bearer "):]

        # ── Introspect ────────────────────────────────────────────────────────
        try:
            info = _introspect(token)
        except Exception as exc:
            return flask.jsonify(
                {"error": f"Token introspection failed: {exc}"}), 401

        if not info.get("active", False):
            return flask.jsonify({"error": "Token is expired or inactive."}), 401

        # ── Confirm it is a service principal (M2M) token ────────────────────
        # Databricks sets token_type to "Bearer" and sub to the SP identifier.
        # A client_id field is present for M2M tokens but absent for PATs.
        client_id = info.get("client_id", "")
        if not client_id:
            return flask.jsonify(
                {"error": "Token does not appear to be an OAuth M2M token "
                          "(no client_id in introspection response)."}), 403

        # ── Optional: pin to a specific service principal ─────────────────────
        if REQUIRED_SP_CLIENT_ID and client_id != REQUIRED_SP_CLIENT_ID:
            return flask.jsonify(
                {"error": f"Token issued to unexpected service principal: "
                          f"{client_id}"}), 403

        # Stash the SP identity so the route handler can log it
        flask.g.sp_client_id = client_id
        return f(*args, **kwargs)

    return decorated


# ── Flask routes ──────────────────────────────────────────────────────────────

@server.route("/health", methods=["GET"])
def health():
    return flask.jsonify({"status": "ok", "service": "app_b"}), 200


@server.route("/upload", methods=["POST"])
@require_m2m_token
def upload():
    if "document" not in flask.request.files:
        return flask.jsonify({"error": "No 'document' field in request."}), 400

    file = flask.request.files["document"]
    if file.filename == "":
        return flask.jsonify({"error": "Filename is empty."}), 400

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    safe_name = os.path.basename(file.filename)
    save_name = f"{timestamp}_{safe_name}"
    save_path = os.path.join(UPLOAD_DIR, save_name)

    file.save(save_path)
    file_size = os.path.getsize(save_path)

    metadata   = dict(flask.request.form)
    sp_id      = getattr(flask.g, "sp_client_id", "unknown")
    entry = {
        "timestamp":       timestamp,
        "filename":        save_name,
        "size_bytes":      file_size,
        "saved_to":        save_path,
        "metadata":        metadata,
        "authenticated_as": sp_id,
    }
    received_log.append(entry)
    print(f"[app_b] ✓ Saved '{save_name}' ({file_size} bytes) "
          f"from service principal {sp_id}")

    return flask.jsonify({"status": "received", **entry}), 200


# ── Dash layout (live log viewer) ─────────────────────────────────────────────

app.layout = html.Div(
    style={"fontFamily": "Arial, sans-serif", "maxWidth": "800px",
           "margin": "40px auto", "padding": "0 20px"},
    children=[
        html.H2("app_b — PDF Receiver (OAuth M2M)"),
        html.P(f"POST endpoint: {HOST}:{PORT}/upload",
               style={"color": "#555", "fontSize": "13px", "marginBottom": "4px"}),
        html.P(
            f"Token validation: Databricks introspection  ({INTROSPECT_URL})",
            style={"color": "#555", "fontSize": "13px", "marginBottom": "4px"},
        ),
        html.P(
            f"Required service principal: "
            f"{REQUIRED_SP_CLIENT_ID or '(any valid M2M token accepted)'}",
            style={"color": "#555", "fontSize": "13px", "marginBottom": "20px"},
        ),

        html.Button("↻ Refresh Log", id="refresh-btn", n_clicks=0,
                    style={"padding": "8px 18px", "cursor": "pointer",
                           "marginBottom": "16px", "borderRadius": "4px",
                           "border": "1px solid #ccc", "fontSize": "13px"}),

        html.Div(id="log-container"),
        dcc.Interval(id="interval", interval=5_000, n_intervals=0),
    ],
)


@app.callback(
    Output("log-container", "children"),
    Input("refresh-btn", "n_clicks"),
    Input("interval",    "n_intervals"),
)
def refresh_log(_clicks, _intervals):
    if not received_log:
        return html.P("No files received yet.",
                      style={"color": "#888", "fontStyle": "italic"})

    rows = []
    for entry in reversed(received_log):
        rows.append(html.Div(
            style={"border": "1px solid #ddd", "borderRadius": "6px",
                   "padding": "12px 16px", "marginBottom": "10px",
                   "backgroundColor": "#f9f9f9"},
            children=[
                html.Div(html.Strong(entry["filename"]),
                         style={"marginBottom": "4px"}),
                html.Div(
                    f"Received: {entry['timestamp']}  |  "
                    f"Size: {entry['size_bytes']} bytes  |  "
                    f"Saved to: {entry['saved_to']}",
                    style={"fontSize": "12px", "color": "#555",
                           "marginBottom": "4px"},
                ),
                html.Div(
                    f"Service principal: {entry.get('authenticated_as', '?')}  |  "
                    f"Metadata: {json.dumps(entry['metadata'], ensure_ascii=False)}",
                    style={"fontSize": "12px", "color": "#444",
                           "fontFamily": "monospace"},
                ),
            ],
        ))
    return rows


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"[app_b] Starting on {HOST}:{PORT}")
    print(f"[app_b] Uploads directory: {UPLOAD_DIR}")
    print(f"[app_b] Introspection URL: {INTROSPECT_URL}")
    app.run(host=HOST, port=PORT, debug=False)
